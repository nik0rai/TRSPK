﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace again
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.dataGridView1.Sort(this.dataGridView1.Columns["NumberOfPassengers"], ListSortDirection.Ascending);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Заполните все поля.", "Ошибка.");
            }
            else
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = textBox1.Text; 
                dataGridView1.Rows[n].Cells[1].Value = numericUpDown1.Value;
                dataGridView1.Rows[n].Cells[2].Value = textBox3.Text; 
                dataGridView1.Rows[n].Cells[3].Value = comboBox2.Text;
                dataGridView1.Rows[n].Cells[4].Value = numericUpDown2.Value;
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox2.Items.AddRange(new string[] { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" });
        }

        private void button11_Click(object sender, EventArgs e)
        {
            try
            {
                DataSet ds = new DataSet(); // создаем пока что пустой кэш данных
                DataTable dt = new DataTable(); // создаем пока что пустую таблицу данных
                dt.TableName = "Planes"; // название таблицы
                dt.Columns.Add("PlaneType"); // название колонок
                dt.Columns.Add("NumberOfPassengers");
                dt.Columns.Add("FlightNumber");
                dt.Columns.Add("DayOfWeek");
                dt.Columns.Add("PlaneCondition");
                ds.Tables.Add(dt); //в ds создается таблица, с названием и колонками, созданными выше

                foreach (DataGridViewRow r in dataGridView1.Rows) // пока в dataGridView1 есть строки
                {
                    DataRow row = ds.Tables["Planes"].NewRow(); // создаем новую строку в таблице, занесенной в ds
                    row["PlaneType"] = r.Cells[0].Value;  //в столбец этой строки заносим данные из первого столбца dataGridView1
                    row["NumberOfPassengers"] = r.Cells[1].Value; // то же самое со вторыми столбцами
                    row["FlightNumber"] = r.Cells[2].Value; //то же самое с третьими столбцами
                    row["DayOfWeek"] = r.Cells[3].Value;
                    row["PlaneCondition"] = r.Cells[4].Value;
                    ds.Tables["Planes"].Rows.Add(row); //добавление всей этой строки в таблицу ds.
                }
                ds.WriteXml("C:\\Users\\Arina\\Data.xml");
                MessageBox.Show("XML файл успешно сохранен.");
            }
            catch
            {
                MessageBox.Show("Невозможно сохранить XML файл.");
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            //if (dataGridView1.Rows.Count > 0) //если в таблице больше нуля строк
            //{
            //    MessageBox.Show("Очистите поле перед загрузкой нового файла.", "Ошибка.");
            //}
            //else
            //{
            if (File.Exists("C:\\Users\\Arina\\Data.xml")) // если существует данный файл
            {
                DataSet ds = new DataSet(); // создаем новый пустой кэш данных
                ds.ReadXml("C:\\Users\\Arina\\Data.xml"); // записываем в него XML-данные из файла

                foreach (DataRow item in ds.Tables["Planes"].Rows)
                {
                    int n = dataGridView1.Rows.Add(); // добавляем новую сроку в dataGridView1
                    dataGridView1.Rows[n].Cells[0].Value = item["PlaneType"]; // заносим в первый столбец созданной строки данные из первого столбца таблицы ds.
                    dataGridView1.Rows[n].Cells[1].Value = item["NumberOfPassengers"]; // то же самое со вторым столбцом
                    dataGridView1.Rows[n].Cells[2].Value = item["FlightNumber"]; // то же самое с третьим столбцом
                    dataGridView1.Rows[n].Cells[3].Value = item["DayOfWeek"];
                    dataGridView1.Rows[n].Cells[4].Value = item["PlaneCondition"];
                }
            }
            else
            {
                MessageBox.Show("XML файл не найден.", "Ошибка.");
            }
        //}
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            //textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            //int n = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[1].Value);
            //numericUpDown1.Value = n;
            //textBox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            //comboBox2.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            //int f = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[4].Value);
            //numericUpDown2.Value = f;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int n = dataGridView1.SelectedRows[0].Index;
                dataGridView1.Rows[n].Cells[0].Value = textBox1.Text;
                dataGridView1.Rows[n].Cells[1].Value = numericUpDown1.Value;
                dataGridView1.Rows[n].Cells[2].Value = textBox3.Text;
                dataGridView1.Rows[n].Cells[3].Value = comboBox2.Text;
                dataGridView1.Rows[n].Cells[4].Value = numericUpDown2.Value;

            }
            else
            {
                MessageBox.Show("Выберите строку для редактирования.", "Ошибка.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index); //удаление
            }
            else
            {
                MessageBox.Show("Выберите строку для удаления.", "Ошибка.");
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                dataGridView1.Rows.Clear();
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                dataGridView1.Rows[i].Selected = false;
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                    if (dataGridView1.Rows[i].Cells[j].Value != null)
                        if (dataGridView1.Rows[i].Cells[j].Value.ToString().Contains(textBox3.Text))
                        {
                            dataGridView1.Rows[i].Selected = true;
                            break;
                        }
            }

        }

        private void button7_Click(object sender, EventArgs e)
        {
            
        }
    }
}
